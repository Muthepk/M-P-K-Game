// --- DOM Elements ---
const startScreen = document.getElementById('start-screen');
const gameScreen = document.getElementById('game-screen');
const resultScreen = document.getElementById('result-screen');

const startBtn = document.getElementById('start-btn');
const homeBtn = document.getElementById('home-btn');
const newGameBtn = document.getElementById('new-game-btn');
const resultHomeBtn = document.getElementById('result-home-btn');

const cells = document.querySelectorAll('.cell');
const statusDisplay = document.getElementById('status-display');
const winnerMessage = document.getElementById('winner-message');
const resultEmoji = document.getElementById('result-emoji');

// --- Game Variables ---
let gameActive = true;
let currentPlayer = "X";
let gameState = ["", "", "", "", "", "", "", "", ""];

const winningConditions = [
    [0, 1, 2], [3, 4, 5], [6, 7, 8],
    [0, 3, 6], [1, 4, 7], [2, 5, 8],
    [0, 4, 8], [2, 4, 6]
];

// --- Event Listeners ---
startBtn.addEventListener('click', () => switchScreen(gameScreen));
homeBtn.addEventListener('click', () => switchScreen(startScreen));
resultHomeBtn.addEventListener('click', () => switchScreen(startScreen));
newGameBtn.addEventListener('click', () => {
    restartGame();
    switchScreen(gameScreen);
});

cells.forEach(cell => cell.addEventListener('click', handleCellClick));

// --- Functions ---

// Helper to handle screen switching
function switchScreen(screenToShow) {
    // Hide all screens
    [startScreen, gameScreen, resultScreen].forEach(screen => {
        screen.classList.remove('active');
        screen.classList.add('hidden');
    });
    // Show target screen
    screenToShow.classList.remove('hidden');
    screenToShow.classList.add('active');
    
    // If going to game screen, reset just in case
    if(screenToShow === gameScreen && !gameActive && gameState.every(cell => cell === "")) {
        restartGame();
    }
}

function handleCellClick(clickedCellEvent) {
    const clickedCell = clickedCellEvent.target;
    const clickedCellIndex = parseInt(clickedCell.getAttribute('data-index'));

    if (gameState[clickedCellIndex] !== "" || !gameActive) {
        return;
    }

    handleCellPlayed(clickedCell, clickedCellIndex);
    handleResultValidation();
}

function handleCellPlayed(clickedCell, clickedCellIndex) {
    gameState[clickedCellIndex] = currentPlayer;
    clickedCell.innerHTML = currentPlayer;
    clickedCell.classList.add(currentPlayer.toLowerCase());
}

function handleResultValidation() {
    let roundWon = false;
    
    for (let i = 0; i <= 7; i++) {
        const winCondition = winningConditions[i];
        let a = gameState[winCondition[0]];
        let b = gameState[winCondition[1]];
        let c = gameState[winCondition[2]];
        
        if (a === '' || b === '' || c === '') continue;
        if (a === b && b === c) {
            roundWon = true;
            break;
        }
    }

    if (roundWon) {
        endGame(false); // False means not a draw (someone won)
        return;
    }

    let roundDraw = !gameState.includes("");
    if (roundDraw) {
        endGame(true); // True means it is a draw
        return;
    }

    handlePlayerChange();
}

function endGame(isDraw) {
    gameActive = false;
    // Delay slightly to let the user see the last move
    setTimeout(() => {
        if (isDraw) {
            winnerMessage.innerText = "It's a Draw!";
            resultEmoji.innerText = "🤝";
        } else {
            winnerMessage.innerText = `Player ${currentPlayer} Wins!`;
            resultEmoji.innerText = "🏆";
        }
        switchScreen(resultScreen);
    }, 500);
}

function handlePlayerChange() {
    currentPlayer = currentPlayer === "X" ? "O" : "X";
    statusDisplay.innerHTML = `Player ${currentPlayer}'s Turn`;
}

function restartGame() {
    gameActive = true;
    currentPlayer = "X";
    gameState = ["", "", "", "", "", "", "", "", ""];
    statusDisplay.innerHTML = `Player X's Turn`;
    
    cells.forEach(cell => {
        cell.innerHTML = "";
        cell.classList.remove('x', 'o');
    });
}